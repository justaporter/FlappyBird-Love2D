function love.conf(t)
    t.window.title = "Flappy Bird"
    -- Don't hardcode a size. 0,0 tells LOVE to use the desktop/display
    -- resolution, so on a handheld running under gptokeyb/CFW this becomes
    -- whatever the panel actually is instead of a fixed 910x512 window that
    -- may not even match the screen's aspect ratio.
    t.window.width = 0
    t.window.height = 0
    t.window.fullscreen = true
    t.window.fullscreentype = "desktop"
    t.window.resizable = true
    t.window.vsync = 1
    t.console = false
end
