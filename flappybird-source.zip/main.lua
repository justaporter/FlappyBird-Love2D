-- Flappy Bird recreation for LÖVE2D
-- Assets: samuelcust/flappy-bird-assets (MIT licensed)
--
-- RESOLUTION HANDLING: no fixed virtual canvas, no letterbox bars, no
-- stretch/squish. Every dimension below is derived from the real screen
-- size at load time (and recomputed on resize), so the playfield always
-- exactly fills the screen at its native aspect ratio. The tradeoff vs a
-- fixed-canvas+letterbox approach: gameplay proportions (how much of the
-- screen height the gap takes up, etc.) are consistent as a % of screen,
-- but the actual pixel layout differs a bit between a 4:3-ish handheld and
-- a 16:9 one, since there's no fixed reference frame anymore.

local WIN_W, WIN_H -- current real screen size, set by recalcLayout()
local SCALE -- sprite draw scale, derived from WIN_H vs a 512px baseline

-- tuning (base values, tuned at the original 910x512 / SCALE=1 baseline —
-- everything gets multiplied by SCALE and re-derived in recalcLayout())
local BASE_H = 512
local GRAVITY_BASE = 1000
local FLAP_VEL_BASE = -320
local MAX_FALL_BASE = 400
local PIPE_SPEED_BASE = 120
local FLAP_FRAME_TIME = 0.12 -- time-based, not pixel-based — untouched

local GRAVITY, FLAP_VEL, MAX_FALL, PIPE_SPEED
local GROUND_Y -- top of the ground strip, in current screen pixels
local BIRD_X -- bird's fixed horizontal screen position

-- pipe randomization pools (bounded, not pure uniform-random — keeps every
-- gap actually passable and stops back-to-back pipes from stacking on top
-- of each other). Stored as fractions of screen height, resolved to pixels
-- in recalcLayout().
local GAP_HEIGHT_FRACS = { 0.146, 0.166, 0.186, 0.205, 0.225 } -- of WIN_H (~75-115 @512)
local GAP_HEIGHTS -- resolved px table

local PIPE_SPACING_SCALE = 1.5
local SPAWN_INTERVAL_MIN = 1.2 * PIPE_SPACING_SCALE
local SPAWN_INTERVAL_MAX = 1.9 * PIPE_SPACING_SCALE
local MAX_GAP_SHIFT_FRAC = 0.3125 -- of WIN_H (160 @512)
local EDGE_MARGIN_FRAC = 0.078 -- of WIN_H (40 @512)
local MAX_GAP_SHIFT, EDGE_MARGIN -- resolved px

local BIRD_COLORS = { "blue", "red", "yellow" }
local PIPE_COLOR = "green"

local images = {}
local sounds = {}

local state = "ready" -- ready | play | gameover
local paused = false -- only meaningful during "play"; esc toggles it
local bg_variant = "day"
local bird_color = "blue"
local last_gap_center = nil

local bird = {}
local pipes = {}
local base_x = 0
local score = 0
local best = 0
local pipe_spawn_timer = 0
local flash = 0 -- white flash on hit
local is_new_best = false

-- gameover reveal sequence: banner slides in, then score panel slides in
-- under it, then the score digits tally up 0->final, then "best" fades in.
-- Timings are in seconds, all tunable below.
local GO_BANNER_SLIDE_T = 0.35   -- gameover banner drop-in duration
local GO_PANEL_DELAY_T = 0.15    -- pause after banner lands before panel slides in
local GO_PANEL_SLIDE_T = 0.30    -- score panel slide-in duration
local GO_TALLY_DELAY_T = 0.15    -- pause after panel lands before digits start counting
local GO_TALLY_RATE = 14         -- digits counted per second during tally (min, scales w/ score)
local GO_TALLY_MIN_T = 0.5       -- minimum tally duration regardless of score
local GO_TALLY_MAX_T = 1.6       -- cap tally duration so huge scores don't take forever
local GO_BEST_DELAY_T = 0.2      -- pause after tally finishes before "best" fades in
local GO_BEST_FADE_T = 0.25      -- "best" fade-in duration

local gameover_t = 0             -- elapsed time since state became "gameover"
local go_tally_duration = GO_TALLY_MIN_T
local go_tally_start_t = 0       -- gameover_t value at which tally begins
local go_best_start_t = 0        -- gameover_t value at which best fade begins
local displayed_score = 0        -- currently-shown (possibly still counting) score value

local function easeOutCubic(t)
    t = math.max(0, math.min(1, t))
    local f = t - 1
    return f * f * f + 1
end

local function loadImg(name)
    return love.graphics.newImage("assets/sprites/" .. name .. ".png")
end

local function playSound(name)
    local s = sounds[name]
    if s then
        s:stop()
        s:play()
    end
end

-- Recompute every screen-dependent value. Called at load and on resize.
-- This is the actual fix: instead of a fixed 910x512 world scaled onto
-- the screen, the world size *is* the screen size, every time.
function recalcLayout()
    WIN_W, WIN_H = love.graphics.getDimensions()

    SCALE = WIN_H / BASE_H

    GRAVITY = GRAVITY_BASE * SCALE
    FLAP_VEL = FLAP_VEL_BASE * SCALE
    MAX_FALL = MAX_FALL_BASE * SCALE
    PIPE_SPEED = PIPE_SPEED_BASE * SCALE

    local ground_h = images and images.base and (images.base:getHeight() * SCALE) or (112 * SCALE)
    GROUND_Y = WIN_H - ground_h

    BIRD_X = math.floor(WIN_W * 0.12) -- ~60/512*something in the original; keep it a fixed fraction of width instead

    GAP_HEIGHTS = {}
    for i, f in ipairs(GAP_HEIGHT_FRACS) do
        GAP_HEIGHTS[i] = math.floor(f * WIN_H)
    end
    MAX_GAP_SHIFT = math.floor(MAX_GAP_SHIFT_FRAC * WIN_H)
    EDGE_MARGIN = math.floor(EDGE_MARGIN_FRAC * WIN_H)
end

function love.load()
    math.randomseed(os.time())
    love.graphics.setDefaultFilter("nearest", "nearest")

    images.bg_day = loadImg("background-day")
    images.bg_night = loadImg("background-night")
    images.base = loadImg("base")
    images.message = loadImg("message")
    images.gameover = loadImg("gameover")
    images.digits = {}
    for i = 0, 9 do
        images.digits[i] = loadImg(tostring(i))
    end

    images.pipe = loadImg("pipe-" .. PIPE_COLOR)

    images.birds = {}
    for _, c in ipairs(BIRD_COLORS) do
        images.birds[c] = {
            loadImg(c .. "bird-upflap"),
            loadImg(c .. "bird-midflap"),
            loadImg(c .. "bird-downflap"),
        }
    end

    for _, n in ipairs({ "wing", "point", "hit", "die", "swoosh" }) do
        sounds[n] = love.audio.newSource("assets/audio/" .. n .. ".wav", "static")
    end

    recalcLayout()
    resetGame()
    playSound("swoosh")
end

function love.resize(w, h)
    recalcLayout()
    -- pipe positions / gap centers were computed against the old screen
    -- size and won't make sense on the new one — a live resize essentially
    -- never happens on a real handheld (res is fixed), but on the PC debug
    -- target this keeps things sane instead of showing garbage briefly.
    resetGame()
end

function resetGame()
    bird = {
        y = WIN_H / 2 - 12 * SCALE,
        vel = 0,
        rot = 0,
        frame = 2,
        frame_t = 0,
    }
    pipes = {}
    base_x = 0
    score = 0
    pipe_spawn_timer = 0
    last_gap_center = nil
    bg_variant = (math.random() < 0.5) and "day" or "night"
    bird_color = BIRD_COLORS[math.random(#BIRD_COLORS)]
    state = "ready"
    paused = false
    gameover_t = 0
    displayed_score = 0
    is_new_best = false
end

local function currentPipeImg()
    return images.pipe
end

local function nextSpawnInterval()
    return SPAWN_INTERVAL_MIN + math.random() * (SPAWN_INTERVAL_MAX - SPAWN_INTERVAL_MIN)
end

local function spawnPipe()
    local gap = GAP_HEIGHTS[math.random(#GAP_HEIGHTS)]
    local lo = math.floor(EDGE_MARGIN + gap / 2)
    local hi = math.floor(GROUND_Y - EDGE_MARGIN - gap / 2)

    local gap_center
    if last_gap_center then
        -- clamp the new gap within MAX_GAP_SHIFT of the previous one so
        -- consecutive pipes can't demand an impossible dive-then-climb
        local min_c = math.max(lo, last_gap_center - MAX_GAP_SHIFT)
        local max_c = math.min(hi, last_gap_center + MAX_GAP_SHIFT)
        if min_c > max_c then min_c, max_c = lo, hi end
        gap_center = math.random(min_c, max_c)
    else
        gap_center = math.random(lo, hi)
    end
    last_gap_center = gap_center

    table.insert(pipes, {
        x = WIN_W + 10,
        gap = gap,
        gap_center = gap_center,
        passed = false,
    })
end

local function birdRect()
    return BIRD_X - 12 * SCALE, bird.y - 8 * SCALE, 24 * SCALE, 16 * SCALE -- slightly forgiving hitbox vs 34x24 sprite
end

local function rectsOverlap(ax, ay, aw, ah, bx, by, bw, bh)
    return ax < bx + bw and ax + aw > bx and ay < by + bh and ay + ah > by
end

local function checkCollisions()
    local bx, by, bw, bh = birdRect()

    if bird.y + 8 * SCALE >= GROUND_Y then
        return true
    end
    if bird.y - 8 * SCALE <= 0 then
        bird.y = 8 * SCALE
        bird.vel = 0
    end

    local pipe_img = currentPipeImg()
    local pipe_w = pipe_img:getWidth() * SCALE
    local pipe_h = pipe_img:getHeight() * SCALE
    for _, p in ipairs(pipes) do
        local top_h = p.gap_center - p.gap / 2
        local bot_y = p.gap_center + p.gap / 2

        if rectsOverlap(bx, by, bw, bh, p.x, top_h - pipe_h, pipe_w, pipe_h) then
            return true
        end
        if rectsOverlap(bx, by, bw, bh, p.x, bot_y, pipe_w, pipe_h) then
            return true
        end
    end
    return false
end

function love.update(dt)
    dt = math.min(dt, 1 / 30)

    -- pause only freezes active gameplay; the ready idle-bounce and the
    -- gameover reveal sequence keep running regardless (there's nothing
    -- stressful to pause during those, and esc during gameover would be
    -- confusing since it's not really "the game" at that point)
    if paused and state == "play" then
        return
    end

    if state == "ready" then
        bird.y = WIN_H / 2 - 12 * SCALE + math.sin(love.timer.getTime() * 4) * 4 * SCALE
        base_x = (base_x - PIPE_SPEED * dt) % -(images.base:getWidth() * SCALE)
    elseif state == "play" then
        bird.vel = math.min(bird.vel + GRAVITY * dt, MAX_FALL)
        bird.y = bird.y + bird.vel * dt

        -- rotation: keep the snappy tilt-up on flap, but once falling, nose
        -- over hard and pin to straight-down (90°) well before terminal
        -- velocity is reached, instead of only hitting 90° right at MAX_FALL
        local vel_frac = bird.vel / SCALE -- de-scaled velocity, consistent across screen sizes
        if vel_frac < 0 then
            bird.rot = math.max(-25, vel_frac * 0.15)
        else
            bird.rot = math.min(90, vel_frac * 0.4)
        end

        base_x = (base_x - PIPE_SPEED * dt) % -(images.base:getWidth() * SCALE)

        pipe_spawn_timer = pipe_spawn_timer - dt
        if pipe_spawn_timer <= 0 then
            spawnPipe()
            pipe_spawn_timer = nextSpawnInterval()
        end

        local pipe_w = currentPipeImg():getWidth() * SCALE
        for _, p in ipairs(pipes) do
            p.x = p.x - PIPE_SPEED * dt
            if not p.passed and p.x + pipe_w < BIRD_X then
                p.passed = true
                score = score + 1
                playSound("point")
            end
        end
        while #pipes > 0 and pipes[1].x < -pipe_w - 20 do
            table.remove(pipes, 1)
        end

        if checkCollisions() then
            state = "gameover"
            gameover_t = 0
            displayed_score = 0
            is_new_best = score > best
            best = math.max(best, score)
            -- tally duration scales gently with score so a score of 2 doesn't
            -- crawl and a score of 80 doesn't take forever, clamped to a range
            go_tally_duration = math.max(GO_TALLY_MIN_T, math.min(GO_TALLY_MAX_T, score / GO_TALLY_RATE))
            go_tally_start_t = GO_BANNER_SLIDE_T + GO_PANEL_DELAY_T + GO_PANEL_SLIDE_T + GO_TALLY_DELAY_T
            go_best_start_t = go_tally_start_t + go_tally_duration + GO_BEST_DELAY_T
            playSound("hit")
            playSound("die")
            flash = 0.15
        end
    elseif state == "gameover" then
        if bird.y + 8 * SCALE < GROUND_Y then
            bird.vel = math.min(bird.vel + GRAVITY * dt, MAX_FALL)
            bird.y = bird.y + bird.vel * dt
            local vel_frac = bird.vel / SCALE
            bird.rot = math.min(90, math.max(-25, vel_frac * 0.4))
        end
        updateGameoverSequence(dt)
    end

    if flash > 0 then
        flash = flash - dt
    end

    bird.frame_t = bird.frame_t + dt
    if state ~= "gameover" and bird.frame_t > FLAP_FRAME_TIME then
        bird.frame_t = 0
        bird.frame = (bird.frame % 3) + 1
    end
end

-- advances the digit tally once we're in the tally window; everything else
-- about the sequence (banner/panel slide, best fade) is purely time-driven
-- and read directly off gameover_t in love.draw, no state needed here
function updateGameoverSequence(dt)
    gameover_t = gameover_t + dt
    if gameover_t <= go_tally_start_t then
        displayed_score = 0
    elseif gameover_t >= go_tally_start_t + go_tally_duration then
        displayed_score = score
    else
        local t = (gameover_t - go_tally_start_t) / go_tally_duration
        displayed_score = math.floor(t * score)
    end
end

local function flap()
    if paused then return end
    if state == "ready" then
        state = "play"
        bird.vel = FLAP_VEL
        playSound("wing")
    elseif state == "play" then
        bird.vel = FLAP_VEL
        playSound("wing")
    elseif state == "gameover" then
        if bird.y + 8 * SCALE >= GROUND_Y then
            resetGame()
            playSound("swoosh")
        end
    end
end

local function togglePause()
    -- pausing only makes sense mid-run; ignore esc on the ready/gameover
    -- screens rather than leaving a stuck "paused" flag hanging around
    if state ~= "play" then return end
    paused = not paused
end

function love.keypressed(key)
    if key == "escape" then
        togglePause()
    elseif key == "space" or key == "up" then
        flap()
    end
end

function love.mousepressed(x, y, button)
    if button == 1 then
        flap()
    end
end

function love.touchpressed()
    flap()
end

local function drawNumber(n, cx, y, scale)
    scale = scale or 1
    local str = tostring(n)
    local widths = {}
    local total = 0
    for i = 1, #str do
        local d = tonumber(str:sub(i, i))
        local w = images.digits[d]:getWidth() * scale
        widths[i] = w
        total = total + w
    end
    local x = cx - total / 2
    for i = 1, #str do
        local d = tonumber(str:sub(i, i))
        love.graphics.draw(images.digits[d], x, y, 0, scale, scale)
        x = x + widths[i]
    end
end

-- Draws the full gameover reveal: "Game Over" banner drops in from above,
-- then a score panel slides in underneath it (score number tallying up from
-- 0, mirroring the original game's counting animation instead of a static
-- number), and finally "best" fades in below once the tally finishes.
function drawGameoverSequence()
    local go_w = images.gameover:getWidth() * SCALE
    local go_h = images.gameover:getHeight() * SCALE
    local go_x = WIN_W / 2 - go_w / 2
    local go_final_y = WIN_H * 0.22

    -- banner: slides down from off-screen top, easing out
    local banner_t = easeOutCubic(gameover_t / GO_BANNER_SLIDE_T)
    local go_start_y = -go_h
    local go_y = go_start_y + (go_final_y - go_start_y) * banner_t
    love.graphics.draw(images.gameover, go_x, go_y, 0, SCALE, SCALE)

    -- score panel: only starts sliding in once the banner has landed
    local panel_start_t = GO_BANNER_SLIDE_T + GO_PANEL_DELAY_T
    if gameover_t < panel_start_t then return end

    local panel_final_y = go_final_y + go_h + WIN_H * 0.05
    local panel_t = easeOutCubic((gameover_t - panel_start_t) / GO_PANEL_SLIDE_T)
    local panel_start_y = panel_final_y - WIN_H * 0.12 -- slides up-and-in from just below its slot
    local panel_y = panel_start_y + (panel_final_y - panel_start_y) * panel_t

    -- panel background card so the tallying number + best line read as one
    -- grouped unit under the banner, with proper spacing between the two
    local panel_w = WIN_W * 0.20
    local panel_h = WIN_H * 0.20
    local panel_x = WIN_W / 2 - panel_w / 2
    love.graphics.setColor(0.94, 0.87, 0.62, math.min(1, panel_t + 0.001))
    love.graphics.rectangle("fill", panel_x, panel_y, panel_w, panel_h, 8 * SCALE)
    love.graphics.setColor(0.6, 0.42, 0.2, math.min(1, panel_t + 0.001))
    love.graphics.rectangle("line", panel_x, panel_y, panel_w, panel_h, 8 * SCALE)
    love.graphics.setColor(1, 1, 1, 1)

    if panel_t < 1 then return end -- don't start the tally until the panel's fully in place

    -- score number, tallying up (displayed_score is advanced in
    -- updateGameoverSequence, driven off gameover_t vs go_tally_start_t/duration)
    local score_y = panel_y + panel_h * 0.16
    drawNumber(displayed_score, WIN_W / 2, score_y, SCALE * 0.65)

    -- "best" line fades in beneath the score once the tally has finished
    if gameover_t < go_best_start_t then return end
    local best_t = math.min(1, (gameover_t - go_best_start_t) / GO_BEST_FADE_T)
    local best_y = panel_y + panel_h * 0.72
    love.graphics.setColor(1, 1, 1, best_t)
    local best_label = is_new_best and ("new best: " .. best) or ("best: " .. best)
    love.graphics.printf(best_label, 0, best_y, WIN_W, "center")
    love.graphics.setColor(1, 1, 1, 1)
end

function love.draw()
    local bg = (bg_variant == "day") and images.bg_day or images.bg_night
    -- background tiled+scaled to fully cover the real screen at whatever
    -- size/aspect it is — no bars, no gaps
    local bg_w = bg:getWidth() * SCALE
    local bg_tiles = math.ceil(WIN_W / bg_w) + 1
    for i = 0, bg_tiles - 1 do
        love.graphics.draw(bg, i * bg_w, 0, 0, SCALE, SCALE)
    end

    local pipe_img = currentPipeImg()
    local pipe_h = pipe_img:getHeight() * SCALE
    for _, p in ipairs(pipes) do
        local top_h = p.gap_center - p.gap / 2
        local bot_y = p.gap_center + p.gap / 2
        -- bottom pipe, upright
        love.graphics.draw(pipe_img, p.x, bot_y, 0, SCALE, SCALE)
        -- top pipe, flipped vertically — anchor (0, pipe_h) means the sprite's
        -- cap (local y=0) needs y offset by -pipe_h so it lands exactly on
        -- the gap edge instead of pipe_h below it
        love.graphics.draw(pipe_img, p.x, top_h - pipe_h, 0, SCALE, -SCALE, 0, pipe_img:getHeight())
    end

    -- base (ground) — tiled and scrolling, generalized to however many
    -- copies the actual screen width needs
    local base_w = images.base:getWidth() * SCALE
    local base_tiles = math.ceil(WIN_W / base_w) + 2 -- +2 covers the scroll wraparound
    for i = 0, base_tiles - 1 do
        love.graphics.draw(images.base, base_x + i * base_w, GROUND_Y, 0, SCALE, SCALE)
    end

    -- bird
    love.graphics.draw(
        images.birds[bird_color][bird.frame], BIRD_X, bird.y,
        math.rad(bird.rot), SCALE, SCALE, 17, 12
    )

    if state == "ready" then
        love.graphics.draw(images.message, WIN_W / 2 - images.message:getWidth() * SCALE / 2, WIN_H * 0.156, 0, SCALE, SCALE)
    elseif state == "play" then
        drawNumber(score, WIN_W / 2, WIN_H * 0.039, SCALE)
    elseif state == "gameover" then
        drawGameoverSequence()
    end

    if flash > 0 then
        love.graphics.setColor(1, 1, 1, flash / 0.15 * 0.6)
        love.graphics.rectangle("fill", 0, 0, WIN_W, WIN_H)
        love.graphics.setColor(1, 1, 1, 1)
    end
end
